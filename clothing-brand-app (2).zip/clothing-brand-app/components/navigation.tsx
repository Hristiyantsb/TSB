"use client"

import { Home, BookOpen, Palette, CheckSquare, Users } from "lucide-react"

interface NavigationProps {
  currentScreen: string
  setCurrentScreen: (screen: string) => void
}

export default function Navigation({ currentScreen, setCurrentScreen }: NavigationProps) {
  const navItems = [
    { id: "dashboard", icon: Home, label: "Home" },
    { id: "resources", icon: BookOpen, label: "Resources" },
    { id: "brand", icon: Palette, label: "Brand" },
    { id: "todo", icon: CheckSquare, label: "Tasks" },
    { id: "community", icon: Users, label: "Community" },
  ]

  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-gray-100 flex justify-around items-center px-4">
      {navItems.map((item) => (
        <button
          key={item.id}
          onClick={() => setCurrentScreen(item.id)}
          className={`flex flex-col items-center justify-center p-2 rounded-lg ${
            currentScreen === item.id ? "text-purple-600" : "text-gray-400"
          }`}
        >
          <item.icon className="w-5 h-5" />
          <span className="text-xs mt-1">{item.label}</span>
        </button>
      ))}
    </div>
  )
}
