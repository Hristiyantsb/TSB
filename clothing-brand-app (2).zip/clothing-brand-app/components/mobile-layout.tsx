import type React from "react"

export default function MobileLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative w-full max-w-md h-[700px] bg-white rounded-[40px] overflow-hidden shadow-xl border-8 border-gray-100">
      <div className="absolute top-0 left-0 right-0 h-6 bg-gray-100 flex justify-center items-center">
        <div className="w-20 h-1 bg-gray-300 rounded-full"></div>
      </div>
      <div className="h-full pt-6 pb-16 overflow-y-auto">{children}</div>
    </div>
  )
}
