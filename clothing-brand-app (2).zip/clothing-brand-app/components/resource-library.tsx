import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"

export default function ResourceLibrary() {
  const categories = [
    {
      id: "business",
      title: "Business Plan",
      color: "bg-blue-100",
      textColor: "text-blue-600",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-blue-600"
        >
          <path d="M16 6h6" />
          <path d="M16 10h6" />
          <path d="M16 14h6" />
          <path d="M16 18h6" />
          <path d="M3 18a2 2 0 0 0 2 2h3a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2Z" />
          <path d="M3 6a2 2 0 0 0 2 2h3a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2Z" />
        </svg>
      ),
      resources: 12,
    },
    {
      id: "logo",
      title: "Logo Design",
      color: "bg-purple-100",
      textColor: "text-purple-600",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-purple-600"
        >
          <circle cx="12" cy="12" r="10" />
          <path d="M8 14s1.5 2 4 2 4-2 4-2" />
          <line x1="9" x2="9.01" y1="9" y2="9" />
          <line x1="15" x2="15.01" y1="9" y2="9" />
        </svg>
      ),
      resources: 8,
    },
    {
      id: "manufacturing",
      title: "Finding Manufacturers",
      color: "bg-orange-100",
      textColor: "text-orange-600",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-orange-600"
        >
          <path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z" />
          <path d="M17 18h1" />
          <path d="M12 18h1" />
          <path d="M7 18h1" />
        </svg>
      ),
      resources: 15,
    },
    {
      id: "marketing",
      title: "Marketing & Sales",
      color: "bg-green-100",
      textColor: "text-green-600",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="text-green-600"
        >
          <path d="M12 2v20" />
          <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
        </svg>
      ),
      resources: 10,
    },
  ]

  const featuredResources = [
    {
      id: 1,
      title: "Creating a Sustainable Clothing Line",
      type: "Guide",
      duration: "15 min read",
      category: "business",
      color: "bg-blue-100",
      textColor: "text-blue-600",
    },
    {
      id: 2,
      title: "Logo Design Principles for Fashion",
      type: "Video",
      duration: "8 min watch",
      category: "logo",
      color: "bg-purple-100",
      textColor: "text-purple-600",
    },
    {
      id: 3,
      title: "Negotiating with Clothing Manufacturers",
      type: "Checklist",
      duration: "5 min read",
      category: "manufacturing",
      color: "bg-orange-100",
      textColor: "text-orange-600",
    },
  ]

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-2">Resource Library</h1>
      <p className="text-gray-600 mb-4">Guides, templates, and tools to help you succeed</p>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input placeholder="Search resources..." className="pl-10 bg-gray-50 border-gray-100" />
      </div>

      <h2 className="font-medium mb-3">Categories</h2>
      <div className="grid grid-cols-2 gap-3 mb-6">
        {categories.map((category) => (
          <div
            key={category.id}
            className={`${category.color} ${category.textColor} p-4 rounded-xl flex flex-col items-center text-center`}
          >
            <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center mb-2">{category.icon}</div>
            <h3 className="font-medium text-sm mb-1">{category.title}</h3>
            <p className="text-xs">{category.resources} resources</p>
          </div>
        ))}
      </div>

      <h2 className="font-medium mb-3">Featured Resources</h2>
      <div className="space-y-3">
        {featuredResources.map((resource) => (
          <div key={resource.id} className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
            <div
              className={`${resource.color} ${resource.textColor} text-xs font-medium px-2 py-1 rounded-full inline-block mb-2`}
            >
              {resource.category === "business" && "Business Plan"}
              {resource.category === "logo" && "Logo Design"}
              {resource.category === "manufacturing" && "Manufacturing"}
              {resource.category === "marketing" && "Marketing"}
            </div>
            <h3 className="font-medium mb-1">{resource.title}</h3>
            <div className="flex items-center text-xs text-gray-500">
              <span className="font-medium mr-2">{resource.type}</span>
              <span>•</span>
              <span className="ml-2">{resource.duration}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
