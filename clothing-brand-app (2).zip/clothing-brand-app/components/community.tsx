import { MessageSquare, Heart, Send } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Community() {
  const posts = [
    {
      id: 1,
      user: {
        name: "Alex Morgan",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content:
        "Just launched my first collection! So excited to share my journey with everyone. It's been a long road but worth every step.",
      time: "2 hours ago",
      likes: 24,
      comments: 8,
      category: "success",
    },
    {
      id: 2,
      user: {
        name: "Jamie Lee",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content:
        "Anyone have recommendations for sustainable fabric suppliers in the US? Looking for organic cotton and recycled polyester.",
      time: "5 hours ago",
      likes: 12,
      comments: 15,
      category: "question",
    },
    {
      id: 3,
      user: {
        name: "Taylor Kim",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content: "Check out this manufacturer I found! They have low MOQs and great quality. Link in comments.",
      time: "1 day ago",
      likes: 36,
      comments: 7,
      category: "resource",
    },
  ]

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-2">Community</h1>
      <p className="text-gray-600 mb-6">Connect with other brand creators</p>

      <Tabs defaultValue="all" className="mb-6">
        <TabsList className="grid grid-cols-4 mb-4">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="success">Success</TabsTrigger>
          <TabsTrigger value="question">Questions</TabsTrigger>
          <TabsTrigger value="resource">Resources</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <img
                src="/placeholder.svg?height=40&width=40"
                alt="Your avatar"
                className="w-10 h-10 rounded-full object-cover"
              />
              <Input placeholder="Share something with the community..." className="bg-gray-50 border-gray-100" />
            </div>
            <div className="flex justify-between text-sm text-gray-500">
              <button className="flex items-center gap-1">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <rect width="18" height="18" x="3" y="3" rx="2" />
                  <circle cx="9" cy="9" r="2" />
                  <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
                </svg>
                Photo
              </button>
              <button className="flex items-center gap-1">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
                  <polyline points="14 2 14 8 20 8" />
                </svg>
                Document
              </button>
              <button className="flex items-center gap-1">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M21 15V6" />
                  <path d="M18.5 18a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z" />
                  <path d="M12 12H3" />
                  <path d="M16 6H3" />
                  <path d="M12 18H3" />
                </svg>
                Poll
              </button>
            </div>
          </div>

          {posts.map((post) => (
            <div key={post.id} className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
              <div className="flex items-start gap-3 mb-3">
                <img
                  src={post.user.avatar || "/placeholder.svg"}
                  alt={post.user.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-medium">{post.user.name}</h3>
                  <p className="text-xs text-gray-500">{post.time}</p>
                </div>
                {post.category === "success" && (
                  <span className="ml-auto px-2 py-1 bg-green-100 text-green-600 rounded-full text-xs">
                    Success Story
                  </span>
                )}
                {post.category === "question" && (
                  <span className="ml-auto px-2 py-1 bg-blue-100 text-blue-600 rounded-full text-xs">Question</span>
                )}
                {post.category === "resource" && (
                  <span className="ml-auto px-2 py-1 bg-orange-100 text-orange-600 rounded-full text-xs">Resource</span>
                )}
              </div>

              <p className="text-sm mb-4">{post.content}</p>

              <div className="flex justify-between text-sm text-gray-500 border-t border-gray-100 pt-3">
                <button className="flex items-center gap-1">
                  <Heart className="w-4 h-4" />
                  {post.likes}
                </button>
                <button className="flex items-center gap-1">
                  <MessageSquare className="w-4 h-4" />
                  {post.comments} Comments
                </button>
              </div>

              <div className="mt-3 pt-3 border-t border-gray-100 flex items-center gap-2">
                <img
                  src="/placeholder.svg?height=32&width=32"
                  alt="Your avatar"
                  className="w-8 h-8 rounded-full object-cover"
                />
                <div className="relative flex-1">
                  <Input placeholder="Write a comment..." className="pr-10 bg-gray-50 border-gray-100" />
                  <button className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="success" className="space-y-4">
          {posts
            .filter((post) => post.category === "success")
            .map((post) => (
              <div key={post.id} className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
                <div className="flex items-start gap-3 mb-3">
                  <img
                    src={post.user.avatar || "/placeholder.svg"}
                    alt={post.user.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="font-medium">{post.user.name}</h3>
                    <p className="text-xs text-gray-500">{post.time}</p>
                  </div>
                  <span className="ml-auto px-2 py-1 bg-green-100 text-green-600 rounded-full text-xs">
                    Success Story
                  </span>
                </div>

                <p className="text-sm mb-4">{post.content}</p>

                <div className="flex justify-between text-sm text-gray-500 border-t border-gray-100 pt-3">
                  <button className="flex items-center gap-1">
                    <Heart className="w-4 h-4" />
                    {post.likes}
                  </button>
                  <button className="flex items-center gap-1">
                    <MessageSquare className="w-4 h-4" />
                    {post.comments} Comments
                  </button>
                </div>
              </div>
            ))}
        </TabsContent>

        <TabsContent value="question" className="space-y-4">
          {posts
            .filter((post) => post.category === "question")
            .map((post) => (
              <div key={post.id} className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
                <div className="flex items-start gap-3 mb-3">
                  <img
                    src={post.user.avatar || "/placeholder.svg"}
                    alt={post.user.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="font-medium">{post.user.name}</h3>
                    <p className="text-xs text-gray-500">{post.time}</p>
                  </div>
                  <span className="ml-auto px-2 py-1 bg-blue-100 text-blue-600 rounded-full text-xs">Question</span>
                </div>

                <p className="text-sm mb-4">{post.content}</p>

                <div className="flex justify-between text-sm text-gray-500 border-t border-gray-100 pt-3">
                  <button className="flex items-center gap-1">
                    <Heart className="w-4 h-4" />
                    {post.likes}
                  </button>
                  <button className="flex items-center gap-1">
                    <MessageSquare className="w-4 h-4" />
                    {post.comments} Comments
                  </button>
                </div>
              </div>
            ))}
        </TabsContent>

        <TabsContent value="resource" className="space-y-4">
          {posts
            .filter((post) => post.category === "resource")
            .map((post) => (
              <div key={post.id} className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
                <div className="flex items-start gap-3 mb-3">
                  <img
                    src={post.user.avatar || "/placeholder.svg"}
                    alt={post.user.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="font-medium">{post.user.name}</h3>
                    <p className="text-xs text-gray-500">{post.time}</p>
                  </div>
                  <span className="ml-auto px-2 py-1 bg-orange-100 text-orange-600 rounded-full text-xs">Resource</span>
                </div>

                <p className="text-sm mb-4">{post.content}</p>

                <div className="flex justify-between text-sm text-gray-500 border-t border-gray-100 pt-3">
                  <button className="flex items-center gap-1">
                    <Heart className="w-4 h-4" />
                    {post.likes}
                  </button>
                  <button className="flex items-center gap-1">
                    <MessageSquare className="w-4 h-4" />
                    {post.comments} Comments
                  </button>
                </div>
              </div>
            ))}
        </TabsContent>
      </Tabs>
    </div>
  )
}
